/*
 * Authored by: Cameron Osborn and Joseph Carlson
 */

package dungeon;
//Interface for attacks
public interface AttackInterface
{
   public void Attack(DungeonCharacter attacker, DungeonCharacter defender);
}